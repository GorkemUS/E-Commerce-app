package com.example.ecommerce.model;

public class Urun {

    public Urun(int urun_id, String urun_adi, String urun_kategori, int urun_fiyat, int urun_sayisi, byte[] urun_resmi, int sepet_bilgisi) {
        this.urun_id = urun_id;
        this.urun_adi = urun_adi;
        this.urun_kategori = urun_kategori;
        this.urun_fiyat = urun_fiyat;
        this.urun_sayisi = urun_sayisi;
        this.urun_resmi = urun_resmi;
        this.sepet_bilgisi = sepet_bilgisi;
    }

    public int getUrun_id() {
        return urun_id;
    }

    public void setUrun_id(int urun_id) {
        this.urun_id = urun_id;
    }

    public String getUrun_adi() {
        return urun_adi;
    }

    public void setUrun_adi(String urun_adi) {
        this.urun_adi = urun_adi;
    }

    public String getUrun_kategori() {
        return urun_kategori;
    }

    public void setUrun_kategori(String urun_kategori) {
        this.urun_kategori = urun_kategori;
    }

    public int getUrun_fiyat() {
        return urun_fiyat;
    }

    public void setUrun_fiyat(int urun_fiyat) {
        this.urun_fiyat = urun_fiyat;
    }

    public int getUrun_sayisi() {
        return urun_sayisi;
    }

    public void setUrun_sayisi(int urun_sayisi) {
        this.urun_sayisi = urun_sayisi;
    }

    public byte[] getUrun_resmi() {
        return urun_resmi;
    }

    public void setUrun_resmi(byte[] urun_resmi) {
        this.urun_resmi = urun_resmi;
    }

    public int getSepet_bilgisi() {
        return sepet_bilgisi;
    }

    public void setSepet_bilgisi(int sepet_bilgisi) {
        this.sepet_bilgisi = sepet_bilgisi;
    }

    int urun_id;
    String urun_adi;
    String urun_kategori;
    int urun_fiyat;
    int urun_sayisi;
    byte[] urun_resmi;
    int sepet_bilgisi;
}
