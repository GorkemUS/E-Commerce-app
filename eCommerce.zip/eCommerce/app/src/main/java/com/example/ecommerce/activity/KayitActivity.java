package com.example.ecommerce.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ecommerce.database.DatabaseHelper;
import com.example.ecommerce.R;
import com.example.ecommerce.util.checkLogin;

import java.io.IOException;

public class KayitActivity extends AppCompatActivity {

    EditText edt_email, edt_name, edt_password;
    Button loginbutton;
    TextView alreadyuserbtn;
    private DatabaseHelper db;
    int i = 0;

    Context mContext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_kayit);

        mContext = this;

        findvById();

        loginbutton.setOnClickListener(v -> setUser());
        alreadyuserbtn.setOnClickListener(v -> {

            Intent i = new Intent(KayitActivity.this, LoginActivity.class);
            startActivity(i);
        });

    }

    private void setUser() {

        if (edt_name.getText().toString().matches("")) {
            Toast.makeText(getApplicationContext(), getString(R.string.lcl_nameCantEmpty), Toast.LENGTH_SHORT).show();
        } else if (edt_password.getText().toString().matches("")) {
            Toast.makeText(getApplicationContext(), getString(R.string.lcl_password_cant_empty), Toast.LENGTH_SHORT).show();
        } else if (edt_email.getText().toString().matches("")) {
            Toast.makeText(getApplicationContext(), getString(R.string.lcl_email_cant_empty), Toast.LENGTH_SHORT).show();
        } else {
            insertUser();
        }


    }


    private void insertUser() {

        try {
            db = new DatabaseHelper(mContext);
            if (db.isDataBaseExist()) {


                if (!db.checkUserIfExists(edt_email.getText().toString(), "user", "usermail")) {


                    db.Insert(edt_name.getText().toString(),
                            edt_email.getText().toString(),
                            edt_password.getText().toString()
                    );
                    checkLogin.setLogin(mContext, true);
                    checkLogin.setUser(mContext, edt_email.getText().toString());
                    Intent i = new Intent(KayitActivity.this, KategoriActivity.class);
                    startActivity(i);
                } else {
                    Toast.makeText(mContext, "Bu mail zaten kayıtlı", Toast.LENGTH_SHORT).show();
                }


            } else {

                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void findvById() {
        edt_email = findViewById(R.id.edt_email);
        edt_name = findViewById(R.id.edt_name);
        edt_password = findViewById(R.id.edt_password);
        loginbutton = findViewById(R.id.loginbtn);
        alreadyuserbtn = findViewById(R.id.alreadyuserbtn);
    }
}