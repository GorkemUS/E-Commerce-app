package com.example.ecommerce.util;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.Nullable;

import java.util.Map;
import java.util.Set;

public class checkLogin implements SharedPreferences {

    public static boolean isLogin;

    @Override
    public Map<String, ?> getAll() {
        return null;
    }

    @Nullable
    @Override
    public String getString(String key, @Nullable String defValue) {
        return null;
    }

    @Nullable
    @Override
    public Set<String> getStringSet(String key, @Nullable Set<String> defValues) {
        return null;
    }

    @Override
    public int getInt(String key, int defValue) {
        return 0;
    }

    @Override
    public long getLong(String key, long defValue) {
        return 0;
    }

    @Override
    public float getFloat(String key, float defValue) {
        return 0;
    }

    @Override
    public boolean getBoolean(String key, boolean defValue) {
        return false;
    }

    @Override
    public boolean contains(String key) {
        return false;
    }

    @Override
    public Editor edit() {
        return null;
    }

    @Override
    public void registerOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener listener) {

    }

    @Override
    public void unregisterOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener listener) {

    }

    public static boolean isLogin(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("Login", Context.MODE_PRIVATE);
        return sharedPref.getBoolean("login_check", false);
    }


    public static void setLogin(Context context, boolean login) {
        SharedPreferences loginPref = context.getSharedPreferences("Login", Context.MODE_PRIVATE);
        Editor editorLogin = loginPref.edit();
        editorLogin.putBoolean("login_check", login);
        editorLogin.apply();
    }


    public static String getUser(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        return sharedPref.getString("user_login", "");
    }


    public static void setUser(Context context, String user) {
        SharedPreferences loginPref = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        Editor editorLogin = loginPref.edit();
        editorLogin.putString("user_login", user);
        editorLogin.apply();
    }
    public static void deleteUser(Context context, String user) {
        SharedPreferences loginPref = context.getSharedPreferences("User", Context.MODE_PRIVATE);
        Editor editorLogin = loginPref.edit();
        editorLogin.clear();
        editorLogin.apply();

    }
}
