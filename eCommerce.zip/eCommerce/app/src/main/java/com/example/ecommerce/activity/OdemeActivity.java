package com.example.ecommerce.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.ecommerce.R;

public class OdemeActivity extends AppCompatActivity {

    private RadioGroup radioSexGroup;
    private Button btnDisplay;
    private RadioButton radioButton2, radioButton1;
    CardView cardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_odeme);
        cardView = findViewById(R.id.cv3);
        cardView.setVisibility(View.GONE);

        radioSexGroup = (RadioGroup) findViewById(R.id.radioSex);
        btnDisplay = (Button) findViewById(R.id.btnDisplay);

        radioButton2 = (RadioButton) findViewById(R.id.radio2);
        radioButton1 = (RadioButton) findViewById(R.id.radio1);
        radioButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cardView.setVisibility(View.GONE);

            }
        });
        radioButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cardView.setVisibility(View.VISIBLE);
            }
        });


    }

}