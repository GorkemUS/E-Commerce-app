package com.example.ecommerce.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.model.Sepet;

import java.util.ArrayList;

public class SepetAdapter extends RecyclerView.Adapter<SepetAdapter.ViewHolder> {


    public SepetAdapter(Activity context, ArrayList<Sepet> kategoriModel, OnItemClickListener onItemClickListener) {
        this.sepetmodel = kategoriModel;
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    Activity context;
    ArrayList<Sepet> sepetmodel;
    OnItemClickListener onItemClickListener;

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.basket_item, parent, false);

        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final Sepet item = sepetmodel.get(position);

        holder.urunAdi.setText(item.getUrun_adi());
        holder.urunFiyat.setText("₺ " + item.getUrun_fiyat());
        holder.urunMiktar.setText(item.getSepet_miktar() + "");


        byte[] image = item.getUrun_resmi();
        if (image != null) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
            holder.imageView.setImageBitmap(bitmap);
        }

        holder.urunAzalt.setOnClickListener(v -> {
            if (item.getSepet_miktar() > 1) {
                onItemClickListener.onclickMinus(position, item.getSepet_id(), item.getSepet_miktar());
                item.setSepet_miktar(item.getSepet_miktar() - 1);
                notifyItemChanged(position);
            }


        });

        holder.urunArttir.setOnClickListener(v -> {
            onItemClickListener.onclickPlus(position, item.getSepet_id(), item.getSepet_miktar());
            item.setSepet_miktar(item.getSepet_miktar() + 1);
            notifyItemChanged(position);
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("tıklanan",item.toString());
                createAlertDialog(position, item.getSepet_id(),item.getUrun_id());

            }
        });

    }

    public void createAlertDialog(int position, int sepet_id,int urun_id) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(context, android.R.style.Theme_Material_Light_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(context);
        }
        builder.setTitle("Bu ürünü sepetten silmek istiyor musun?")
                .setCancelable(false)
                .setNegativeButton(context.getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setPositiveButton("Sil", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        sepetmodel.remove(position);
                        notifyItemRemoved(position);
                        notifyDataSetChanged();
                        onItemClickListener.deleteFromSepet(sepet_id,urun_id);

                    }
                }).create();
        builder.show();
    }

    @Override
    public int getItemCount() {
        return sepetmodel.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView urunAdi;
        TextView urunMiktar;
        TextView urunFiyat;
        ImageView urunArttir;
        ImageView urunAzalt;
        ImageView imageView, delete;


        public ViewHolder(View view) {
            super(view);

            urunAdi = view.findViewById(R.id.urun_adi_tv);
            urunFiyat = view.findViewById(R.id.urun_fiyat_tv);
            urunMiktar = view.findViewById(R.id.urun_miktar_tv);
            urunArttir = view.findViewById(R.id.plus);
            urunAzalt = view.findViewById(R.id.minus);
            imageView = view.findViewById(R.id.product_image);
            delete = view.findViewById(R.id.delete);


        }
    }
}