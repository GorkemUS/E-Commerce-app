package com.example.ecommerce.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ecommerce.R;
import com.example.ecommerce.adapter.OnItemClickListener;
import com.example.ecommerce.adapter.SepetAdapter;
import com.example.ecommerce.adapter.UrunAdapter;
import com.example.ecommerce.database.DatabaseHelper;
import com.example.ecommerce.model.Kategori;
import com.example.ecommerce.model.Sepet;
import com.example.ecommerce.model.Urun;

import java.io.IOException;
import java.util.ArrayList;

public class SepetActivity extends AppCompatActivity {

    private DatabaseHelper db;
    public ArrayList<Sepet> array;
    Context context;
    RecyclerView recyclerView;
    TextView toplam_tv, onayla_tv;
    Button back;
    int toplam;
    OnItemClickListener onItemClickListener;
    View noItemView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basket);
        context = this;
        recyclerView = findViewById(R.id.recyclerView3);
        onayla_tv = findViewById(R.id.onayla_tv);
        toplam_tv = findViewById(R.id.toplam);
        back = findViewById(R.id.back);
        noItemView = findViewById(R.id.no_item);
        getAllSepet();

        onayla_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SepetActivity.this, OdemeActivity.class);
                startActivity(i);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SepetActivity.this, ListActivity.class);
                intent.putExtra("kategori", ListActivity.getKategori(context));
                startActivity(intent);
                finish();
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void getAllSepet() {
        array = new ArrayList<>();

        try {
            db = new DatabaseHelper(context);
            if (db.isDataBaseExist()) {

                int count = Integer.parseInt(db.getCountAll("sepet", "sepet_id"));


                for (int i = 0; i < count; i++) {
                    array.add(new Sepet(Integer.parseInt(db.getAllfromTable(i, "sepet", "sepet_id")),
                            Integer.parseInt(db.getAllfromTable(i, "sepet", "urun_id")),
                            db.getAllfromTable(i, "sepet", "urun_adi"),
                            Integer.parseInt(db.getAllfromTable(i, "sepet", "urun_fiyat")),
                            db.getImage(i, "sepet", "urun_resmi"),
                            Integer.parseInt(db.getAllfromTable(i, "sepet", "sepet_miktar"))
                    ));
                    toplam += Integer.parseInt(db.getAllfromTable(i, "sepet", "urun_fiyat")) * Integer.parseInt(db.getAllfromTable(i, "sepet", "sepet_miktar"));


                }

                initRecyclerview();
                toplam_tv.setText(toplam + " ₺");

                noItemView.setVisibility(count < 1 ? View.VISIBLE : View.GONE);


            } else {

                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void setToplam() {
        toplam = 0;
        try {
            db = new DatabaseHelper(context);
            if (db.isDataBaseExist()) {

                int count = Integer.parseInt(db.getCountAll("sepet", "sepet_id"));
                for (int i = 0; i < count; i++) {
                    toplam += Integer.parseInt(db.getAllfromTable(i, "sepet", "urun_fiyat")) * Integer.parseInt(db.getAllfromTable(i, "sepet", "sepet_miktar"));
                }

                toplam_tv.setText(toplam + " ₺");
                noItemView.setVisibility(count < 1 ? View.VISIBLE : View.GONE);

            } else {


                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateDb(int sepet_id, int miktar) {

        try {
            db = new DatabaseHelper(context);
            if (db.isDataBaseExist()) {


                db.updateValue("sepet",
                        String.valueOf(sepet_id),
                        miktar
                );

                setToplam();
            } else {

                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void deleteDb(int sepet_id, int urun_id) {

        try {
            db = new DatabaseHelper(context);
            if (db.isDataBaseExist()) {


                db.deleteSepet("sepet",
                        "sepet_id",
                        String.valueOf(sepet_id)
                );
                db.updateSepet("urun",
                        String.valueOf(urun_id),
                        0
                );
                setToplam();
            } else {

                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void initRecyclerview() {

        onItemClickListener = new OnItemClickListener() {


            @Override
            public void onclickPlus(int position, int sepet_id, int miktar) {

                Log.d("gelenmiktar", miktar + "");

                miktar = miktar + 1;
                updateDb(sepet_id, miktar);

            }

            @Override
            public void onclickMinus(int position, int sepet_id, int miktar) {

                Log.d("gelenmiktar", miktar + "");

                miktar = miktar - 1;
                updateDb(sepet_id, miktar);

            }

            @Override
            public void deleteFromSepet(int sepet_id, int urun_id) {
                deleteDb(sepet_id, urun_id);

            }


        };

        SepetAdapter adapter = new SepetAdapter(SepetActivity.this, array, onItemClickListener);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
    }
}