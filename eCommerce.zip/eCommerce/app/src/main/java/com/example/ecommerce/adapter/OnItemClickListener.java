package com.example.ecommerce.adapter;

public interface OnItemClickListener {
    void onclickPlus(int position, int sepet_id, int miktar);

    void onclickMinus(int position, int sepet_id, int miktar);

    void deleteFromSepet(int sepet_id,int urun_id);

}
