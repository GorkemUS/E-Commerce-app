package com.example.ecommerce.adapter;

import com.example.ecommerce.model.Urun;

public interface UrunOnItemClickListener {
    void onclick(Urun urun);
}
