package com.example.ecommerce.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.example.ecommerce.BuildConfig;
import com.example.ecommerce.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DatabaseHelper extends SQLiteOpenHelper {

    private Context mycontext;
    private static final String DATABASE_NAME = "database.sqlite";
    @SuppressLint("SdCardPath")
    private static String DB_PATH = "/data/data/" + BuildConfig.APPLICATION_ID + "/databases/";


    // Database Version

    private static final int DATABASE_VERSION = 1;

    // Database Name

    public DatabaseHelper(Context context) throws IOException {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

        this.mycontext = context;

        if (isDataBaseExist()) {
            //db aç ve kullan
        } else {
            //       Log.d("database","yok");
            importDatabaseFromAssets();
        }

    }

    // Creating Tables

    @Override
    public void onCreate(SQLiteDatabase db) {


    }


    @SuppressLint("SdCardPath")
    public boolean isDataBaseExist() {

        DB_PATH = "/data/data/" + mycontext.getPackageName() + "/databases/";
        File dbFile = new File(DB_PATH + DatabaseHelper.DATABASE_NAME);
        return dbFile.exists();

    }

    private void importDatabaseFromAssets() {
        try {
            InputStream myInput = mycontext.getAssets().open(DATABASE_NAME);
            File outFileName = mycontext.getDatabasePath(DATABASE_NAME);
            OutputStream myOutput = new FileOutputStream(outFileName);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = myInput.read(buffer)) > 0) {
                myOutput.write(buffer, 0, length);
            }
            //      Log.d("database",myOutput+"");

            // Close the streams
            myOutput.flush();
            myOutput.close();
            myInput.close();
        } catch (FileNotFoundException e) {

            e.printStackTrace();

        } catch (IOException e) {


            e.printStackTrace();

        }
    }

    // Upgrading database

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {


    }


    public boolean CheckIsDataAlreadyInDBorNot(String TableName,
                                               String dbfield, String fieldValue) {
        SQLiteDatabase db = this.getReadableDatabase();

        String Query = "Select * from " + TableName + " where " + dbfield + " = " + fieldValue;
        Cursor cursor = db.rawQuery(Query, null);
        if (cursor.getCount() <= 0) {
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }

    public boolean checkUserIfExists(String email, String tableName, String columnName) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(tableName + "",

                new String[]{columnName},
                "usermail like" + "" + "'%" + email + "%'", null, null, null, null, null);

        if (cursor.getCount() <= 0) {
            cursor.close();
            return false;
        }
        cursor.close();
        return true;


    }

    public boolean checkUserPassword(String password, String tableName, String columnName) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(tableName + "",

                new String[]{columnName},
                "userpassword like" + "" + "'%" + password + "%'", null, null, null, null, null);

        if (cursor.getCount() <= 0) {
            cursor.close();
            return false;
        }
        cursor.close();
        return true;


    }

    public String getUrunfromKategoriCount(String tableName, String columnName, String kategori) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(tableName + "",

                new String[]{columnName},
                "urun_kategori like" + "" + "'%" + kategori + "%'", null, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        return String.valueOf(cursor.getCount());

    }

    public String getUrunfromKategori(int id, String tableName, String columnName, String kategori) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(tableName + "",

                new String[]{columnName},
                "urun_kategori like" + "" + "'%" + kategori + "%'", null, null, null, null, null);

        if (cursor.getCount() > 0)
            cursor.moveToPosition(id);

        return cursor.getString(cursor.getColumnIndex(columnName));
    }


    public byte[] getUrunfromKategoriImage(int id, String tableName, String columnName, String kategori) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(tableName + "",

                new String[]{columnName},
                "urun_kategori like" + "" + "'%" + kategori + "%'", null, null, null, null, null);

        if (cursor.getCount() > 0)
            cursor.moveToPosition(id);

        return cursor.getBlob(cursor.getColumnIndex(columnName));

    }


    public String getCountAll(String tableName, String columnName) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(tableName,

                new String[]{columnName},
                null, null, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        return String.valueOf(cursor.getCount());

    }


    public String getAllfromTable(int id, String tableName, String columnName) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(tableName + "",

                new String[]{columnName},
                null, null, null, null, null, null);

        if (cursor.getCount() > 0)

            cursor.moveToPosition(id);

        return cursor.getString(cursor.getColumnIndex(columnName));
    }

    public byte[] getImage(int id, String tableName, String columnName) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(tableName + "",

                new String[]{columnName},
                null, null, null, null, null, null);

        if (cursor.getCount() > 0)

            cursor.moveToPosition(id);

        return cursor.getBlob(cursor.getColumnIndex(columnName));
    }


    public void Insert(String name, String email, String password ) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("username", name);
        values.put("userpassword", password);
        values.put("usermail", email);


        db.insertOrThrow("user", null, values);


        Log.d("user", "eklendi");
    }

    public void InsertSepet(String tableName, int urun_id, String urun_adi, String urun_fiyat,
                            byte[] image, int sepet_miktar) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();

        cv.put("urun_id", urun_id);
        cv.put("urun_adi", urun_adi);
        cv.put("urun_fiyat", urun_fiyat);
        cv.put("urun_resmi", image);
        cv.put("sepet_miktar", sepet_miktar);


        db.insertOrThrow(tableName, null, cv);


        Log.d("sepet", "eklendi");
    }

    public void deleteSepet(String tableName, String columnName, String id) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(tableName,
                columnName + "=?", new String[]{String.valueOf(id)});

    }


    public void updateValue(String tableName, String sepet_id, int miktar) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("sepet_miktar", miktar);


        long result = db.update(tableName, cv, "sepet_id = ?", new String[]{sepet_id});

        if (result == -1) {
        } else {
        }

        db.close();

    }

    public void updateSepet(String tableName, String urun_id, int sepet_bilgisi) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("sepet_bilgisi", sepet_bilgisi);


        long result = db.update(tableName, cv, "urun_id = ?", new String[]{urun_id});

        if (result == -1) {
        } else {
        }

        db.close();

    }


}