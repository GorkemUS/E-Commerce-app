package com.example.ecommerce.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ecommerce.R;
import com.example.ecommerce.adapter.KategoriAdapter;
import com.example.ecommerce.adapter.UrunAdapter;
import com.example.ecommerce.adapter.UrunOnItemClickListener;
import com.example.ecommerce.database.DatabaseHelper;
import com.example.ecommerce.model.Kategori;
import com.example.ecommerce.model.Sepet;
import com.example.ecommerce.model.Urun;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class ListActivity extends AppCompatActivity {

    private DatabaseHelper db;
    public ArrayList<Urun> array;
    Context context;
    RecyclerView recyclerView;
    String kategori_adi;
    UrunOnItemClickListener urunOnItemClickListener;
    ConstraintLayout item_basket_layout;
    TextView sepet_count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_list);
        context = this;
        recyclerView = findViewById(R.id.recyclerView2);
        item_basket_layout = findViewById(R.id.item_basket_layout);
        sepet_count = findViewById(R.id.basket_tv);

        setKategori(getIntent().getExtras().getString("kategori"),context);
        kategori_adi = getKategori(context);

        getAllUrun();

        item_basket_layout.setOnClickListener(v -> {
            Intent intent = new Intent(ListActivity.this, SepetActivity.class);
            startActivity(intent);
        });


    }

    private void getAllUrun() {
        array = new ArrayList<>();

        try {
            db = new DatabaseHelper(context);
            if (db.isDataBaseExist()) {

                int count = Integer.parseInt(db.getUrunfromKategoriCount("urun", "urun_id", kategori_adi));


                for (int i = 0; i < count; i++) {
                    array.add(new Urun( Integer.parseInt(db.getUrunfromKategori(i, "urun", "urun_id", kategori_adi)),
                            db.getUrunfromKategori(i, "urun", "urun_adi", kategori_adi),
                            db.getUrunfromKategori(i, "urun", "urun_kategori", kategori_adi),
                            Integer.parseInt(db.getUrunfromKategori(i, "urun", "urun_fiyat", kategori_adi)),
                            Integer.parseInt(db.getUrunfromKategori(i, "urun", "urun_sayisi", kategori_adi)),
                            db.getUrunfromKategoriImage(i, "urun", "urun_resmi", kategori_adi),
                            Integer.parseInt(db.getUrunfromKategori(i, "urun", "sepet_bilgisi", kategori_adi))
                    ));

                }

                initRecyclerview();
                setSepetCount();

                Log.d("gelenarray", array.toString());


            } else {

                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void insertUrun(Urun urun) {

        try {
            db = new DatabaseHelper(context);
            if (db.isDataBaseExist()) {


                db.InsertSepet(
                        "sepet",
                        urun.getUrun_id(),
                        urun.getUrun_adi(),
                        String.valueOf(urun.getUrun_fiyat()),
                        urun.getUrun_resmi(),
                        1
                );
                Toast.makeText(context, "Ürün sepete eklendi", Toast.LENGTH_SHORT).show();

                db.updateSepet("urun",
                        String.valueOf(urun.getUrun_id()),
                        1
                );


            } else {

                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    private void setSepetCount() {

        try {
            db = new DatabaseHelper(context);
            if (db.isDataBaseExist()) {

                int count = Integer.parseInt(db.getCountAll("sepet", "sepet_id"));
                sepet_count.setText(count+"");

            } else {

                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void initRecyclerview() {
        urunOnItemClickListener = new UrunOnItemClickListener() {
            @Override
            public void onclick(Urun urun) {
                insertUrun(urun);
                setSepetCount();

            }
        };

        UrunAdapter adapter = new UrunAdapter(ListActivity.this, array, urunOnItemClickListener);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
    }

    public static String getKategori(Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("Prefs", Context.MODE_PRIVATE);
        return sharedPref.getString("kategori", "kategori1");
    }

    public static void setKategori(String kategori,Context context) {
        SharedPreferences sharedPref = context.getSharedPreferences("Prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor prefEditor = sharedPref.edit();
        prefEditor.putString("kategori", kategori);
        prefEditor.apply();    }

}