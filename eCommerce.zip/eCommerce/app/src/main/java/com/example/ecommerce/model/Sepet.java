package com.example.ecommerce.model;

import java.util.Arrays;

public class Sepet {

    public Sepet(int sepet_id, int urun_id, String urun_adi, int urun_fiyat, byte[] urun_resmi, int sepet_miktar) {
        this.sepet_id = sepet_id;
        this.urun_id = urun_id;
        this.urun_adi = urun_adi;
        this.urun_fiyat = urun_fiyat;
        this.urun_resmi = urun_resmi;
        this.sepet_miktar = sepet_miktar;
    }

    public int getSepet_id() {
        return sepet_id;
    }

    public void setSepet_id(int sepet_id) {
        this.sepet_id = sepet_id;
    }

    public int getUrun_id() {
        return urun_id;
    }

    public void setUrun_id(int urun_id) {
        this.urun_id = urun_id;
    }

    public String getUrun_adi() {
        return urun_adi;
    }

    public void setUrun_adi(String urun_adi) {
        this.urun_adi = urun_adi;
    }

    public int getUrun_fiyat() {
        return urun_fiyat;
    }

    public void setUrun_fiyat(int urun_fiyat) {
        this.urun_fiyat = urun_fiyat;
    }

    public byte[] getUrun_resmi() {
        return urun_resmi;
    }

    public void setUrun_resmi(byte[] urun_resmi) {
        this.urun_resmi = urun_resmi;
    }

    public int getSepet_miktar() {
        return sepet_miktar;
    }

    public void setSepet_miktar(int sepet_miktar) {
        this.sepet_miktar = sepet_miktar;
    }

    int sepet_id;
    int urun_id;
    String urun_adi;
    int urun_fiyat;
    byte[] urun_resmi;
    int sepet_miktar;

    @Override
    public String toString() {
        return "Sepet{" +
                "sepet_id=" + sepet_id +
                ", urun_id=" + urun_id +
                ", urun_adi='" + urun_adi + '\'' +
                ", urun_fiyat=" + urun_fiyat +
                ", urun_resmi=" + Arrays.toString(urun_resmi) +
                ", sepet_miktar=" + sepet_miktar +
                '}';
    }
}
