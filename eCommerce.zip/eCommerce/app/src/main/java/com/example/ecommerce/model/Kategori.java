package com.example.ecommerce.model;

import java.util.Arrays;

public class Kategori {

    public Kategori(int kategori_id, String kategori_adi, byte[] kategori_resmi) {
        this.kategori_id = kategori_id;
        this.kategori_adi = kategori_adi;
        this.kategori_resmi = kategori_resmi;
    }

    public int getKategori_id() {
        return kategori_id;
    }

    public void setKategori_id(int kategori_id) {
        this.kategori_id = kategori_id;
    }

    public String getKategori_adi() {
        return kategori_adi;
    }

    public void setKategori_adi(String kategori_adi) {
        this.kategori_adi = kategori_adi;
    }

    public byte[] getKategori_resmi() {
        return kategori_resmi;
    }

    public void setKategori_resmi(byte[] kategori_resmi) {
        this.kategori_resmi = kategori_resmi;
    }

    int kategori_id;
    String kategori_adi;
    byte[] kategori_resmi;


    @Override
    public String toString() {
        return "Kategori{" +
                "kategori_id=" + kategori_id +
                ", kategori_adi='" + kategori_adi + '\'' +
                ", kategori_resmi=" + Arrays.toString(kategori_resmi) +
                '}';
    }
}
