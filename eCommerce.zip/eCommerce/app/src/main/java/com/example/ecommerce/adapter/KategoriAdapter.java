package com.example.ecommerce.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.activity.ListActivity;
import com.example.ecommerce.model.Kategori;

import java.util.ArrayList;

public class KategoriAdapter extends RecyclerView.Adapter<KategoriAdapter.ViewHolder> {


    public KategoriAdapter(Activity context, ArrayList<Kategori> kategoriModel) {
        this.kategoriModel=kategoriModel;
        this.context = context;
    }

    Activity context;
    ArrayList<Kategori> kategoriModel;

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.kategori_item, parent, false);

        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final Kategori item = kategoriModel.get(position);


        holder.titleTextview.setText(item.getKategori_adi());
        byte[] image = item.getKategori_resmi();
        if(image!=null){
            Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
            holder.imageView.setImageBitmap(bitmap);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToUrun(item.getKategori_adi());
            }
        });

    }

    private void goToUrun(String kategori){
        Intent i = new Intent(context, ListActivity.class);
        i.putExtra("kategori",kategori);
        context.startActivity(i);

    }

    @Override
    public int getItemCount() {
        return kategoriModel.size();
    }



    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView titleTextview;
        ImageView imageView;


        public ViewHolder(View view) {
            super(view);
            titleTextview = view.findViewById(R.id.titleTextview);

            imageView = view.findViewById(R.id.urunImageView);


        }
    }
}