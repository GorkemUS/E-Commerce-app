package com.example.ecommerce.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.model.Urun;

import java.util.ArrayList;

public class UrunAdapter extends RecyclerView.Adapter<UrunAdapter.ViewHolder> {


    public UrunAdapter(Activity context, ArrayList<Urun> kategoriModel,UrunOnItemClickListener urunOnItemClickListener) {
        this.urunModel = kategoriModel;
        this.context = context;
        this.urunOnItemClickListener=urunOnItemClickListener;
    }

    Activity context;
    ArrayList<Urun> urunModel;
    UrunOnItemClickListener urunOnItemClickListener;

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.urun_item, parent, false);

        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final Urun item = urunModel.get(position);

        holder.urunAdi.setText(item.getUrun_adi());
        holder.urunFiyat.setText("₺"+item.getUrun_fiyat());
        holder.sepete_ekle_tv.setText(item.getSepet_bilgisi() ==0 ? "Sepete Ekle":"Sepete Eklendi");

        holder.sepete_ekle_tv.setEnabled(item.getSepet_bilgisi() == 0);




        byte[] image = item.getUrun_resmi();
        if (image != null) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
            holder.imageView.setImageBitmap(bitmap);
        }

        holder.sepete_ekle_tv.setOnClickListener(v -> {
            urunOnItemClickListener.onclick(item);
            holder.sepete_ekle_tv.setEnabled(false);
            holder.sepete_ekle_tv.setText("Sepete Eklendi");

        });

    }

    @Override
    public int getItemCount() {
        return urunModel.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView urunAdi;
        TextView urunFiyat;
        ImageView imageView;
        TextView sepete_ekle_tv;


        public ViewHolder(View view) {
            super(view);

            urunAdi = view.findViewById(R.id.urun_adi_tv);
            urunFiyat = view.findViewById(R.id.urun_fiyat_tv);
            sepete_ekle_tv = view.findViewById(R.id.sepete_ekle_tv);
            imageView = view.findViewById(R.id.urunImageView);


        }
    }
}