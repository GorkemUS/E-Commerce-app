package com.example.ecommerce.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ecommerce.R;
import com.example.ecommerce.database.DatabaseHelper;
import com.example.ecommerce.util.checkLogin;

import java.io.IOException;

public class LoginActivity extends AppCompatActivity {


    EditText edt_email, edt_password;
    Button loginbtn;
    TextView statustv;
    private DatabaseHelper db;

    Context mContext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        mContext=this;

        edt_email = findViewById(R.id.edt_email);
        edt_password = findViewById(R.id.edt_password);
        loginbtn=findViewById(R.id.loginbtn);
        statustv = findViewById(R.id.statustv);


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();


            }
        });

        statustv.setOnClickListener(v -> {
            Intent i = new Intent(LoginActivity.this,KayitActivity.class);
            startActivity(i);
        });



    }


    private void loginUser() {

        try {
            db = new DatabaseHelper(mContext);
            if (db.isDataBaseExist()) {

                if (edt_email.getText().toString().matches("")) {
                    Toast.makeText(getApplicationContext(), getString(R.string.lcl_email_cant_empty), Toast.LENGTH_SHORT).show();
                } else if (edt_password.getText().toString().matches("")) {
                    Toast.makeText(getApplicationContext(), getString(R.string.lcl_password_cant_empty), Toast.LENGTH_SHORT).show();
                } else {
                    if (db.checkUserIfExists(edt_email.getText().toString(), "user", "usermail")) {

                        if (db.checkUserPassword(edt_password.getText().toString(), "user", "usermail")) {
                            checkLogin.setLogin(mContext, true);
                            checkLogin.setUser(mContext, edt_email.getText().toString());
                            Intent i = new Intent(LoginActivity.this, KategoriActivity.class);
                            startActivity(i);
                        } else {
                            Toast.makeText(mContext, "Şifre Yanlış", Toast.LENGTH_SHORT).show();


                        }


                    } else {
                        Toast.makeText(mContext, "Kullanıcı Adı Yanlış", Toast.LENGTH_SHORT).show();

                    }

                }


            } else {

                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}