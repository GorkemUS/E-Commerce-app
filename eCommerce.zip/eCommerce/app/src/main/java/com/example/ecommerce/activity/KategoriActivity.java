package com.example.ecommerce.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

import com.example.ecommerce.database.DatabaseHelper;
import com.example.ecommerce.R;
import com.example.ecommerce.adapter.KategoriAdapter;
import com.example.ecommerce.model.Kategori;

import java.io.IOException;
import java.util.ArrayList;

public class KategoriActivity extends AppCompatActivity {

    private DatabaseHelper db;
    public  ArrayList<Kategori> array;
    Context context;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;

        recyclerView= findViewById(R.id.recyclerView);

        getAllCategory();
    }


    private void getAllCategory() {
        array = new ArrayList<>();

        try {
            db = new DatabaseHelper(context);
            if (db.isDataBaseExist()) {

                int count = Integer.parseInt(db.getCountAll("kategori", "kategori_id"));


                for (int i = 0; i < count; i++) {
                    array.add(new Kategori(i+1,
                            db.getAllfromTable(i, "kategori", "kategori_adi"),
                            db.getImage(i, "kategori", "kategori_resmi")));

                }

                initRecyclerview();

                Log.d("gelenarray", array.toString());



            } else {

                Log.d("database", "gg");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void initRecyclerview(){

        KategoriAdapter adapter = new KategoriAdapter(KategoriActivity.this, array);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
    }
}